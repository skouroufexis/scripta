<template>

    <main id="Menu" class="container">
        <div class="container">
            

            

            
        </div>


    </main>    
</template>


<script>
export default {
    name:'Menu',

    data:function(){
        return{
           //
        }
    },

    props:[],

    watch:{
        //  attachments:function(newVal){
        //        this.new_attachments=newVal;  
               
               
        //  }, 
        //  dossier:function(newVal){
        //        this.dossier=newVal;   
               
        //  },
        //  tags:function(newVal){
        //          this.new_tags=newVal;                 
        //  },
        
    },

    methods:{
        
        methodName:function(){},
        

       //

    },
}
</script>


<style>

   

</style>

